class Person 

    def name
        # create a name variable
        name = "Steve"
    end 

    def age
        # create age variable here
        age = 23;

    end

    def children
        # create children array here
        children = ['child1', 'child2', 'child3', 'child4'];


    end

    def address

        # create address hash here
        adress = {
            city: 'London',
            county: 'county1',
            town: 'town2',
            house_number: 4,
            street: 'streetname',
            postcode: 'N18 2LF',
            email_addresses: ['email@hotmail.co.uk', 'email2"hotmail.com']

        }

    end

    def password

        # do not change these variables
        favourite_things = ["motorbike" , "cat" , "travel"]
        memorable_stuff = {
          birth_year: 1983,
          mothers_name: "Eve",
          birth_town: "Richmond"
        }

        password = "#{favourite_things[1]} #{memorable_stuff[:birth_town]}"

    end

end