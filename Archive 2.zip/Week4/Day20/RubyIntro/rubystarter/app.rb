# puts "Hi, This is about as basic as Ruby script can be. Hope you enjoy it. Right, I'm off";

# require 'mac/say';

# # Mac::Say.say ("ruby ruby ruby ruby ahh ahh ahh ahh ahh ahh");

# first_name = 'Bilal';

# puts first_name.length;

# last_name = 'Hassan';

# full_name = first_name + last_name;

# puts full_name;

# # interpollation

# full_name2 = "#{first_name} #{last_name}"; # space inbetween words

# fullname3 = [first_name, last_name]; # new line

# puts full_name2;

# puts fullname3;

# my_name = :bilal;
# my_num = 10;

# # puts my_name;

# my_name = 'test user';

# puts my_name;
# puts ++my_num;

# my_array = [1, 3, 6, 9];
# my_array = [1, "my name here", 3, 6,"I love music", 9, :test];

# # puts my_array[0];

# puts my_array.shuffle;

# hast data type

person = {
	name:'Bilal',
	:age => 23,
}

puts person[:name];


my_string = "welcome to ruby";

puts my_string.start_with?('w');
puts my_string.end_with?('y');



