class Square 

	attr_accessor :side_length

	def initialize side_length

		self.side_length = side_length

	end

	def calculate_area length
		length ** 2
	end

	def calculate_perimeter length
		length * 4
	end

end

# square1 = Square.new(5)

# puts square1.side_length
# p square1.calculate_area
# p square1.calculate_perimeter
