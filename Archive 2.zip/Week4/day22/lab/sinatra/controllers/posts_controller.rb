class PostsController < Sinatra::Base # no need for rrquire as you are inheritting from a gem. 
	
	configure :development do 
		register Sinatra::Reloader
    end

    # sets root as the parent-directory of current file
    set :root, File.join(File.dirname(__FILE__), '..')

    # sets the view directory 
    set :views, Proc.new { File.join(root, "views") }


 #    get "/" do 
 #    #	"<h1>Welcome to Ruby: Get method without parameter</h1>"
 #    erb :'index' # get the index file in the views folder
	# end

	# get "/:id" do 

	# 	@title = params[:id]
	#     erb :'show' 
	# end

	get "/names" do # get the info from the url into the page
		#age
		@age = params[:age]
		#firstname
		@first_name = params[:first_name]
		#lastname
		@last_name = params[:last_name]
	    erb :'details' 

	end

end
