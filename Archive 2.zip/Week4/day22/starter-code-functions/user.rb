class Users

	attr_accessor :email

	def initialize 
		self.email = email
	end 
	def Speak
		puts "ruby ruby ruby ruby"
	end 


end
