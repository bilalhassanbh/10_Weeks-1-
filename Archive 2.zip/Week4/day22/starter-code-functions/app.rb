# link the person.rb page

require_relative "person.rb"

person_three = Person.new "Bob", "Male", 50, 1.86, 85
person_four = Person.new "Bilal", "Male", 23, 1.72, 75


# p  person_three.calculate_bmi
# p  person_three.calculate_calories

# p person_four.calculate_bmi
# p person_four.calculate_calories

# puts person_four.description

puts Person.trainer
puts Person.trainer = 'Joe'
puts Person.trainer
person_three.Speak


# puts Person.trainer = "joe"
# p person_three.name
# p person_three.name = "Fred"
# p person_four

# # Person one
# person_three.name = "Bob";
# person_three.sex = "Male";
# person_three.age = 50;
# person_three.height = 1.86;
# person_three.weight = 85;

# # Person two
# person_four.name = "Bilal";
# person_four.sex = "Male";
# person_four.age = 23;
# person_four.height = 1.72;
# person_four.weight = 75;


# OOP way of doing both data above
# person_three "Markson", "Male", 50, 1.86, 90
# person_four "Joe", "Male", 55, 1.89, 100


# # calculate BMI for person one
# person_one_bmi = calculate_bmi person_one_height, person_one_weight

# # calculate BMI for person two
# person_two_bmi = calculate_bmi person_two_height, person_two_weight

# # calculate bmi for person three
# calculate_bmi person_three
# # calculate bmi for person four
# calculate_bmi person_four

# # calculate required calories for person one
# person_one_calories = calculate_calories(person_one_sex, person_one_height, person_one_weight, person_one_age)

# # calculate required calories for person two
# person_two_calories = calculate_calories(person_two_sex, person_two_height, person_two_weight, person_two_age)


# # calculate calories for person three
# calculate_calories(person_three)
# # calculate calories for person four
# calculate_calories(person_four)

# puts "#{person_one_name} has a BMI of #{person_one_bmi}. Recommend calorie intake is #{person_one_calories} calories"

# puts "#{person_two_name} has a BMI of #{person_two_bmi}. Recommend calorie intake is #{person_two_calories} calories"