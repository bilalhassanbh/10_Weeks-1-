# create class for health calculator

require_relative "user.rb"
# class person in ruby
class Person < Users

	@@trainer = "Markson"

	def self.trainer
		@@trainer
	end 
	def self.trainer= (value)
		@@trainer = value
	end

	attr_accessor :name, :sex, :weight, :height, :age

	def initialize name, sex, age, height, weight
	# puts "ruby please tell me you are awesome" 
		self.name = name
		self.sex = sex
		self.age = age
		self.height = height
		self.weight = weight

	end 

# create class to calculate bmi
	def calculate_bmi #height,weight
		(weight / (height  ** 2)).to_i
	end

	def calculate_calories #sex, height, weight, age
		if sex == "Male"
			bmr = 66.47 + (13.7 * weight) + (5 * height * 100) - (6.8 * age)
		else
			bmr = 655.1 + (9.6 * weight) + (1.8 * height * 100) - (4.7 * age)
		end

		bmr.to_i
	end

	def description 

		"#{name} has a BMI of #{calculate_bmi}. Recommended calories are #{calculate_calories}"

	end


end