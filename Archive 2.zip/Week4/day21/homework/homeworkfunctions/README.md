# SPARTA Functions Lab

## Timings 

60 - 90 Mins 

## Summary 

Using what you have learned already, work through  the starter code and create the relevant function for each task. 

The spec folder contains a testing script that will show you what each function needs to do and whether you have written it correctly. You can run these tests like this:

```
rspec spec
```

The first time you run this command you will notice all the tests report RED. Your task is to write the functions required that will pass the tests.

