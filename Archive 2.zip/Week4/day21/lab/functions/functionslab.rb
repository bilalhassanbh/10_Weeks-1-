#intro to functions in ruby

def say_hello first_name, last_name

	puts "#{first_name} #{last_name}"

end

say_hello "Bilal", "Hassan"


def say_hello1 name, age=25

	# puts full_name = name + " " + age
	puts "#{name} #{age}"

end

def say_hello2 name, age

	# puts full_name = name + " " + age
	puts "#{name} #{age}"

end

say_hello1 "Bilal"
say_hello2 "BILAL", 23







# splat

def say_splat name, *other_names
	# puts name + " " + other_names.to_s
	puts "#{name} #{other_names.to_s}"

	other_names.each do |names |
		puts "welcome #{name} #{names}"
	end
end

say_splat "BiLaL", "HASSAN", "hassan"
