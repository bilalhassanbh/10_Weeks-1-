# # Ruby controls file structures 

# number = 10

# # if number > 20 then
# # 	puts "If it is true"
# # else
# # 	puts "False"
# # end

# if number < 20 then
# 	puts "Less than 20"

# elsif number > 15
# 	puts "More than 15"

# elsif number > 12
# 	puts "more than 12"
	
# else
# 	puts "any other value"

# end


# # ruby ternary operator ? :

# name = number > 10? "Bilal" : "Hassan"

# puts name;

# .eql? # textual comparison 

# equal? # precise comparison


# puts (number > 1) | (number < 10)
# puts (number > 1) || (number < 10) # short circuit operator

# LOOPS

# for i in 0...10
# 	puts i
# end

# # while

# i = 0;

# while i  < 10
# 	puts i
# 	i+=1
# end

# my_people = ["people1", "people2", "people3", "people4"]

# p my_people.sample

# my_people.each do | x | # for each time bring something from the array into   
# 	puts x
# end


# my_people = {
# 	people1: 'person1',
# 	people2: 'person2',
# 	people3: 'person3',
# 	people4: 'person4',

# }

# my_people.each do | y, x |
# 	p "#{y} index of #{x}"
# 	end 


# number = 5

# loop do 
# 	puts "run continuously"

# 	number += 1

# 	if (number >10 )
# 		break
# 	end
# end



# i = 0

# until i > 10 do
# 	puts "Until : #{i}"
# 	i+=1
# endi = 0



# begin
# 	puts "Do Until : #{i}"
# 	i+=1

# end until i > 90



# for i in 'a'..'z'
# 	puts i
# end 



# map

# more_words = ["one", "two", "three"]

# new_reverse_words = more_words.map do | word |
# 	word.reverse 

# end 

# # puts new_reverse_words




# num_array = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

# multiply_by_two = num_array.map do | t |
# 	t * 2
# end 

# puts num_array


# num_array2 = [2, 4, 6, 8, 10, 12, 14, 16, 18, 20]


# num_array2.map! do | k |
# 	k * 3
# end
#  puts num_array2




# reduce function
some_numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]

sum = some_numbers.reduce 0 do | total, numbers | 
	total + numbers
end

puts "total of array: #{sum}"










