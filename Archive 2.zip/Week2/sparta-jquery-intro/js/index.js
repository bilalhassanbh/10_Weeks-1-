$(function (event) {
	console.log('Dom is ready');
	//var myh1 = document.getElementById("myh1");
	// myh1.addEventListener("click", function(event) {
	// 	alert("you clicked on the header")
	// })
	$("#myh1").on("click", function(event){
		alert("you clicked on the heeader using $");
	});

	$("p").css("color", "red");

	$("p").on("click", function(event){
		$("p").css("color", "blue");
	});
	$("li").css("display", "none");
	$("*").css({ 'border': '1px solid #FFFF00'});
	$



});


