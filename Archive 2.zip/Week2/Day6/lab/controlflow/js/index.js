// console.log(5+5);
// // alert(5+5);

// var shownumber = 5 + 6;

// var l = "Markson";
// var j = "M";
// var y = true;
// var t = 12;
// var z = null;
// var pi = 3.14
// var milage = 25000;
// var student = ["Joe", "Childs", 20, "spartan007", ["1 Castle Yard Richmond"]];
// // alert(student[4][0]);

// var another = {"firstname":"Joe", "Lastname":"Childs", "age":20};

// if ( !!true ) { // false, 0, null, any other is true
// 	alert("It is true");
// }
// else 
// {
// 	alert("WRONG!!");
// }

// var money_in_my_pocket = 11; // giving the value of money in my pocket
// if (money_in_my_pocket > 10) 
// {
// 	console.log("Another drink please");
// } 
// else if (money_in_my_pocket > 5) 
// {
// 	console.log("Just crisps then");
// }
// else if (money_in_my_pocket > 2) {
// 	console.log("Lend me a fiver");
// }
// else 
// {
// 	console.log("I'm off home then");
// }



// var condition = 0;
// switch(condition){
// 	case 0:
// 		console.log("Value 0");
// 		// break;
// 	case 1:
// 		console.log("value 1");
// 		break;
// 	case 2: 
// 		console.log("value 2");
// 		break;

// 	default:
// 	console.log("out of range");
// }

// alert(another["firstname"]);

// car properties
// var car = {

// 	colour: "Black",
// 	Reg:"FE5 9YP",
// 	EngineSize: 4.5,
// 	Milage: milage};

// console.log(car);

// // alert(shownumber);

// // alert('My outline in JavaScript');

// console.log(shownumber + 10);





var dayofweek = "Monday";
switch(dayofweek){
	case "Monday":
		console.log("It is Monday");
		// break;
	case "Tuesday":
		console.log("It is Tuesday");
		// break;
	case "Wednesday": 
		console.log("It is Wednesday");
		break;
	case "Thursday":
	console.log("It is Thursday");
	break;
	case "Friday":
		console.log("It is Friday");
		break;
	case "Saturday": 
		console.log("It is Saturday");
		break;
	case "Sunday":
		console.log("It is Sunday")
	default:
	console.log("I dont understand");
}