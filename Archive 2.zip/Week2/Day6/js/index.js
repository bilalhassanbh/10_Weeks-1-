// console.log(5+5);
// // alert(5+5);

// var shownumber = 5 + 6;

// var l = "Markson";
// var j = "M";
// var y = true;
// var t = 12;
// var pi = 3.14
var milage = 25000;
// var student = ["Joe", "Childs", 20, "spartan007", ["1 Castle Yard Richmond"]];
// alert(student[4][0]);

// var another = {"firstname":"Joe", "Lastname":"Childs", "age":20};
// alert(another["firstname"]);

// car properties
var car = {

	colour: "Black",
	Reg:"FE5 9YP",
	EngineSize: 4.5,
	Milage: milage};

console.log(car);

// alert(shownumber);

// alert('My outline in JavaScript');

// console.log(shownumber + 10);