// alert("This is js where every day is a paradise.")

// Loops

// while loop

// var condition = 10;

// var gameexit = true;


// while (gameexit) {

// 	alert("game on");


// 	var exitchoice = prompt("do you want to exit the game? yes or no");

// 	if (exitchoice == "yes") {
// 		gameexit = false;
// 	}
// }

// for (var i = 0; i < 10; i++) {

// 	console.log("value at iteration at: " + i);

// }

// do while loop
// var gameexit = true;

// do 
// {
// 	alert("game on");

// 	var exitchoice = prompt("do you want to exit the game? yes or no");

// 	if (exitchoice == "yes") 
// 	{
// 		gameexit = false;
// 	}
// }

// while (gameexit);



var fruits = ["orange", "grape", "lemon"];
// var i = 0;

// //alert(fruits[0]); // give out orange

// for(;i < fruits.length; i++) {
// 	console.log("Fruit: " + fruits[i]);
// }


for(var key in fruits) {
	console.log(key + " " + fruits[key]);
}