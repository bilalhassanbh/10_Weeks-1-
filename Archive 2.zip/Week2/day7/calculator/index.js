

var caclop = true;

while(caclop) {
	// get the user inputs
    var value1 = parseInt(prompt('enter first value')); 
    var value2 = parseInt(prompt('enter the second value'));
    var choice = prompt('Choose your action (a)dd (s)ubtract (m)ultiply (d)ivide') || "a";

    if (choice == "a") {
    	alert(value1 + value2);
    }
    else if (choice == "s") {
    	alert(value1 - value2);
    }
    else if (choice == "m") {
    	alert(value1 * value2);
    }
    else{
    	alert(value1 / value2);
    }


 var caclop = (prompt("Do you want to run again? true or false") === 'true');

}


