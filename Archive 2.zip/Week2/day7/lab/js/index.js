	// var value1 = parseInt(prompt('enter first value')); 
 //    var value2 = parseInt(prompt('enter the second value'));
 //    var choice = prompt('Choose your action (a)dd (s)ubtract (m)ultiply (d)ivide') || "a";

 //    if (choice == "a") {
 //    	alert(value1 + value2);
 //    }
 //    else if (choice == "s") {
 //    	alert(value1 - value2);
 //    }
 //    else if (choice == "m") {
 //    	alert(value1 * value2);
 //    }
 //    else{
 //    	alert(value1 / value2);
 //    }


 // 	var caclop = (prompt("Do you want to run again? true or false") === 'true');

 // 	function function_name(argument) {
 // 		// body...
 // 		return;
 // 	}

	// function add(value1, value2) {
	// 	return value1+value2;
	// 	arguments[0]+arguments[1];
	// }

	// var result = add(value1, value2);
	// console.log(result);

















// function createCounter() {

// 	var total = 0;

// 	return function() {
// 		total++;
// 		return total;
// 	}
// }

// var counter = createCounter();

// counter();
// counter();
// counter();
// var total = counter();
// console.log(total);


// for (var i = 0; i < 10; i++) {
	
// 	setTimeout(function() {
// 		console.log(i);

// 	} , (i * 1000 ) ) 

// }




//onTimerComplete();


//testhoist();
var testhoist = function onTimerComplete() {
	var message = "Time finished";
	console.log(message);
}

testhoist();