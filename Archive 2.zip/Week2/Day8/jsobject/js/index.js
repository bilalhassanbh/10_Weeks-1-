// alert("Linked")

var myvariable = "bilal"

function sayHello(){
	var lastname = " hassan"
	return myvariable + lastname;
}

var Car = new Object();
console.log(typeof Car);

Car.model = "BMW";
Car.series = "3 Series";
Car.engine = "3.0";
Car.colour = "Grey";
Car.year = "2015";
Car.move = function() {
	return "gone in 60 seconds";
}
Car.brake = function() {
	return "Car has stopped";
}
Car.passengers = ["Bilal", "James", "John"];

console.log(Car);


// function person(){
// 	this.lastname = " James";
// }

// var person = Object.create(person.prototype);
// person.lastname = "Don";
// console.log(person.lastname);

var person = function() {
	this.lastname = " James";
	this.firstname = "Don";
	this.age = 25;
	this.sayHello = function() {
		return "Hello";
	}
}

var person1 = new person();
var person2 = new person();
console.log(person1.lastname);
console.log(person2.age);	

var personnew = function(firstname, lastname, age) {
	this.lastname = lastname;
	this.firstname = firstname;
	this.age = age;
	this.sayHello = function() {
		return "Hello";
	}
}

var person3 = new personnew("John", "Doe", 35);
var person4 = new personnew("Jane", "Doe", 35);
console.log(person3.lastname)
console.log(person4.lastname)






//JSON
var Trainer = {

	name: "Markson.",
	age: 25,
	team: ["Joe", "Lucie"],
	sayHello: function() {
		return "Hello Engineering 7. From ";
	}
}

console.log(Trainer.sayHello() + Trainer.name);