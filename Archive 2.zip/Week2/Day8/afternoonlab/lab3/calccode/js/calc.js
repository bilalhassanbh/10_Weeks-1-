// // var number1; // first number clicked 
// // var number2; // second number clicked 
// // var operatorclick; // operator used to make calculation
// // var total; // include a total of the sum, but make empty

// // // GET THE FIRST NUMBER

// // document.addEventListener("DOMContentLoaded" , function(event) {
// // 	var number1 = document.getElementsByClassName("buttonNum");

// // 	for(var i = 0; i < number1.length; i++) {
// // 		number1[i].addEventListener("click", function (event) {
// // 		document.getElementById("screen").innerHTML = event.target.innerHTML;

// // 		var number1val = event.target.innerHTML;

// // 		//var number2 = new event.target.innerHTML;

// // 		console.log("Number 1: " + number1val); // should show the first number in the console
// // 	});
// // }

// // // GET THE SECOND NUMBER

// // var number2 = document.getElementsByClassName("buttonNum");

// // 	for(var i = 0; i < number2.length; i++) {
// // 		number2[i].addEventListener("click", function(event) {
// // 		document.getElementById("screen").innerHTML = event.target.innerHTML;

// // 		var number2val = event.target.innerHTML;

// // 		//var number2 = new event.target.innerHTML;

// // 		console.log("Number 2: " + number2val); // should show the first number in the console
// // 	});
// // }

// // var operation = document.getElementsByClassName("operator");

// // 	for(var i = 0; i < operation.length; i++) {
// // 		operation[i].addEventListener("click", function (event) {
// // 		document.getElementById("screen").innerHTML = event.target.innerHTML;

// // 		var operatorclick = event.target.innerHTML;
// // 		//console.log(operatorclick);

// // 		number2 = event.target.innerHTML;
// // 	});
// // }

// // var equal = document.getElementsByClassName("equals");
// // 	for(var i = 0; i < equal.length; i++) {
// // 		equal[i].addEventListener("click", function (event) {
// // 		document.getElementById("screen").innerHTML = event.target.innerHTML;

// // 		var equalbutton = event.target.innerHTML;

// // 		total = number1+number2;
// // 		console.log(equal[i]);

// // 	});

// // //console.log(total);



// // }

// // });









// // console.log("This is a test");
// // var result = 8 + 9;

// var num1 = 0; // initialise num1 as 0 to use as a condition
// var opz = false;
// var num2 = false;

// var buttons = document.getElementsByClassName("buttonNum");
// var operators = document.getElementsByClassName("operator");
// var display = document.getElementById("screen");
// var AC = document.getElementsByClassName("buttonClear");
// var equals = document.getElementsByClassName("equals");

// // Add event listner to AC

// AC[0].addEventListener("click", function(event) {
// 	display.innerHTML = "Sparta Calculator";
// 	num1 = 0;
// 	opz = false;
// })
// // Add event listener to equals button
// equals[0].addEventListener("click", MyCalculation);
// // main calculator function
// function MyCalculation() {
// 	var result = "";
// 	if(opz == "+") {
// 		result = num1+num2;
// 	}
// 	else if (opz == "/" ){
// 		result = num1/num2;
// 	}
// 	else if (opz == "*") {
// 		result = num1*num2;
// 	}
// 	else {
// 		result = num1-num2;
// 	}
// 	display.innerHTML = result;
// 	//console.log(8+9);
// }
// // add event listener to number button
// for (var i = 0; i < buttons.length; i++) {
// 	buttons[i].addEventListener("click", function(event){

// 		//console.log(event.target.innerHTML);
// 		//display.innerHTML = event.target.innerHTML;
// 		// 8 + 9
// 		if(num1 == 0) {
// 			// capture the firts number when selected
// 			display.innerHTML = event.target.innerHTML;
// 			num1 = parseInt(event.target.innerHTML);
// 			opz = true;
// 		}
// 		else if (num2 == true) {
// 			display.innerHTML = event.target.innerHTML;
// 			num2 = parseInt(event.target.innerHTML);
// 			//opz = false;
// 		}



// 	});
// }
// for (var i = 0; i < operators.length; i++) {
// 	operators[i].addEventListener("click", function(event){

// 		if(opz == true) {
// 			display.innerHTML = event.target.innerHTML;
// 			opz = event.target.innerHTML;
// 			num2 = true;
// 		}

// 		//console.log(event.target.innerHTML);
// 		//display.innerHTML = event.target.innerHTML;

// 	});
// }


// // console.log(buttons);
// // console.log(operators);
// // console.log(display);






//Consider what data needs to be captured in order to run the program
//a + b = ?
var num1 = '';
var num2 = '';
var operator = '';
var buttons = document.getElementsByClassName('buttonNum');
var operators = document.getElementsByClassName('operator');
var display = document.getElementById('screen');
var clear = document.getElementById('buttonClear');
var equals = document.getElementById('equals');
var reset = false

for (var i = 0; i < buttons.length; i++) {
	buttons[i].addEventListener('click', function(event){
		//console.log(event.target.innerHTML); 
		if (operator) {
			num2 += event.target.innerHTML;
			display.innerHTML = num2;
		} else if (!(operator)) {
			num1 += event.target.innerHTML;
			display.innerHTML = num1;
		}
	});
}

for (var i = 0; i < operators.length; i++) {
	operators[i].addEventListener('click', function(event){
		if (num1 == '' || num2 !== '') {

		} else {
			operator = event.target.innerHTML;
			display.innerHTML = event.target.innerHTML;
		}
	});
}

equals.addEventListener('click', function(event) {
	switch (operator) {
		case '+':
			display.innerHTML = parseInt(num1) + parseInt(num2);
		break;
		case '-':
			display.innerHTML = parseInt(num1) - parseInt(num2);
		break;
		case '*':
			display.innerHTML = parseInt(num1) * parseInt(num2);
		break;
		case '/':
			display.innerHTML = parseInt(num1) / parseInt(num2);
		break;
	}
	reset = true
        if (reset) {
            num1 = display.innerHTML
            num2 = ''
        }
})

clear.addEventListener('click', function(event){
	display.innerHTML = 'Sparta Calculator'
	reset = true
        if (reset) {
            num1 = ''
            num2 = ''
            operator = ''
        }
})



$(function (event){


$('.buttonNum').on("click", function(event){
	$(".buttonNum").css("color", "red");
});

});





















