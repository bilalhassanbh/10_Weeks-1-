// // var playerX = 'X';
// // var playerO = 'O'; // creating both players
// // var next = '';
// // var tabled = $('td'); // get td link from html page
// // var playerturn = $('h2'); // get the player in play to display
// // var reset = false;
// // var restart =$('#reset')

// // for (var i = 0; i < tabled.length; i++ ) {
// // 	$('td').on('click', function player1(event) {
// // 		$('.player1Turn').css('color', 'green');
// // 		$(this).html('X');
// // 		//player2();

// // 		$('td').on('click', function player2(event) {
// // 			$('.player2turn').css('color', 'blue');
// // 			$(this).html('O');
// // 			return playerX;
// // 		})
// // 	});
// // };


// $(function(){

// 	// confirm js is linked and works

// 	console.log("all set");
// 	var squares = $('td'); // target the td tag to get the boxes
// 	var resetbutton = $('#reset'); // target the reste button. it is an id so use #
// 	var stepcounter = 0; // step counter
// 	var winningmoves = $([ [0, 1, 2], [3, 4, 5], [6, 7, 8] [0, 3, 6], [1, 4, 7], [2, 5, 8], [0, 4, 8], [2, 4, 6] ]) // multi dimension array
// 	var playerXmoves = []; // array of player x moves
// 	var playeromoves = []; // array of player o moves




// 	// box to turn to X when you click
// 	squares.on('click', function(event){

// 		if(stepcounter % 2 == 0) {

// 			$(this).html('X');
// 			playerXmoves.push($(this).attr('data-num'));
// 			//console.log('playerX: ', playerXmoves);
// 			playerXmoves.each(index, value) {
// 				checkForWin(playerXmoves, 'X');
// 			}

// 		}
// 		else {

// 			$(this).html('O');
// 			playeromoves.push($(this).attr('data-num')); {
// 			//console.log('player O: ', playeromoves);
// 			// checkForWin(playeromoves, 'O');
// 			playeromoves.each(index, value) {
// 				checkForWin(playeromoves, 'O');

// 			}
// 		}
// 	}

// }

// 		// increment the step counter and reset the board once full
// 		++stepcounter;
// 		if(stepcounter == 10){
// 			squares.html('');
// 			stepcounter = 0;

// 		}
// 		//console.log('inside boxes');
// 	});

// 	// reset button to clear the board

// 	resetbutton.on('click', function(event){
// 		//console.log('inside boxes');
// 		squares.html('');
// 	});

// 	function checkForWin(movesArray, name) {
// 		winningmoves.each(function(index, combination) {
// 			var winCounter = 0;
// 			$(combination).each(function(index, winningbox) {
// 				if(movesArray.indexOf(winningbox) !== -1){
// 					winCounter++;
// 					console.log(winCounter);
// 				}
// 				if (winCounter === 3){
// 					alert('Game over, ', + name + " wins");
// 					resetBoard();
// 				}
// 			})
// 		})
// 	}



// });



$(function(){
  var $boxes = $("td");
  var $turnText = $(".playerTurn")
  var counter = 1;
  var winCounter = 0;
  var OMoves = [];
  var XMoves = [];
  var $winningCombinations = $([[0,1,2],[3,4,5],[6,7,8],
  [0,3,6],[1,4,7],[2,5,8],[0,4,8],[2,4,6]]);
  function start(){
    addXandOListener();
    addResetListener();
  }
  function addXandOListener(){
    $boxes.click(addXorO)
  }
  function addXorO(){
    var $box = $(this);
    // If the box has nothing then lets go on to add an X or O
    if ($box.html().length === 0){
      // If counter is even add an O
      if (counter % 2 === 0) {
        // Push the move into the OMoves array
        OMoves.push(parseInt($box.attr("data-num")));
        // Set the value and class of the element clicked
        $box.html("O").attr("class","O");
        // Set the text of the turn element
        $turnText.html("It is X's turn");
        // increment the counter so the turn alternate
        counter++;
        // After each click check for a win condition
        checkForWin(OMoves, "O");
      }
      else {
        XMoves.push(parseInt($box.attr("data-num")));
        $box.html("X").attr("class","X");
        $turnText.innerHTML = "It is O's turn";
        counter++;
        checkForWin(XMoves, "X");
      }
    // If the counter is equal to 10 it means the board is full
    if (counter >= 10){
      $turnText.html("Game Over!");
      var conf = confirm("It's a draw, do you want to play again?");
      if(conf){
        resetBoard();
      }
    }
   }
  }
  // Add reset button listener to call the rest board function
  function addResetListener(){
    $("#reset").click(resetBoard);
  }
  // Lets check to see if there is a winning combination in out moves array
  function checkForWin(movesArray, name){
    $winningCombinations.each(function(index, combination){
      // win counter
      winCounter = 0;
      $(combination).each(function(index, winningBox){
        // If moves array contains winning box add 1 to winCounter
        if(movesArray.indexOf(winningBox) !== -1){
          // Add one
          winCounter++;
        }
        // If counter gets to we have a winning combination
        if(winCounter === 3){
          alert("Game over, " + name + " wins!");
          resetBoard();
        }
      })
    })
  }
  // Reset our board to its original state
  function resetBoard(){
    $boxes.html("").attr("class", "clear")
    $turnText.html("It is X's turn");
    OMoves = [];
    XMoves = [];
    winCounter = 0;
    counter = 1;
  }
  start();
})