class Lesson < ApplicationRecord
end
