class Post

	attr_accessor :id, :title, :body

	def self.open_connection

		conn = PG.connect( dbname: "blog" )

	end

	def self.all 

		conn = self.open_connection

		sql = "SELECT id, title, body FROM post ORDER BY id"



		result = conn.exec(sql)

		posts = result.map do | tuple | # for every result, there is one record line

			self.hydrate tuple

		end 

		posts

	end 

	def self.hydrate post_data

		post = Post.new

		post.id = post_data['id']
		post.title = post_data['title']
		post.body = post_data['body']

		post

	end 

	def save 

		conn = Post.open_connection

		sql ="INSERT INTO post (title, body) VALUES ( '#{self.title}', '#{self.body}' ) "

		result = conn.exec(sql)
	end 

end