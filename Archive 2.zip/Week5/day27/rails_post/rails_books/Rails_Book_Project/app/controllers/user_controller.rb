class UserController < ApplicationController
  def hello
  	@name = params[:name]
  end

  def goodbye
  	render :goodbye
  end
end
