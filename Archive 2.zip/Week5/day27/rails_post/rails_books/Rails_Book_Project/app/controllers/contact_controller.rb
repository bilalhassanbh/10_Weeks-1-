class ContactController < ApplicationController


	def contact

		@name = params[:contact]
		render :contact

	end

end