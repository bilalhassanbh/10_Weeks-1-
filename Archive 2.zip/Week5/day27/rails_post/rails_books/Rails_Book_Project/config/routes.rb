Rails.application.routes.draw do

  resources :customers
  resources :books
  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html


# get "static/home"

	root "static#home" # direct to the home page when loading localhost:3000

	get "/hello/:name" , to: "static#hello" # direct to name when hello and name is inserted

	get "/contact/:contact" , to: "contact#contact"
	
	get 'user/goodbye' , to: "user#goodbye"

	get '/user/:name' , to: "user#hello"


end
