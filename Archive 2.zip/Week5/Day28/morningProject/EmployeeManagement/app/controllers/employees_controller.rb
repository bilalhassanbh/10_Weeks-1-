class EmployeesController < ApplicationController

	def index

		@employee = Employee.all

		render :index

	end 

	def new 

		@employee = Employee.new # the html will have access to the blank employee

		render :new

	end

	def create 

		@employee = Employee.new(employee_params) # create a new employee but use the new params 

		if(@employee.save)
			redirect_to "/" # redirect to the index page once created
		end

	end 

	def edit 
		id = params[:id]
		@employee = Employee.find(id)

		render :edit
	end 

	def show


		@employee = Employee.find(params[:id].to_i)
		render :show

	end

	def employee_params

		params.require(:employee).permit(:id, :name, :department, :age, :email) # grab the params and have access to the stuff

	end

end
