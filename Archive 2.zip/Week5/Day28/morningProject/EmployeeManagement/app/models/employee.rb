class Employee < ApplicationRecord

	
end
