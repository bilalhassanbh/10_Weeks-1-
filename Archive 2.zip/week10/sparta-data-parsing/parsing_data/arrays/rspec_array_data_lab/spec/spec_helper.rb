RSpec.configure do |config|
  config.formatter = :documentation
end
