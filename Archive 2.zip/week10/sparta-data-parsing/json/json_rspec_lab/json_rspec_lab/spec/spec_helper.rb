require 'json'
  require_relative '../json_class_parse_walkthrough'


  RSpec.configure do |config|
    config.formatter = :documentation
  end