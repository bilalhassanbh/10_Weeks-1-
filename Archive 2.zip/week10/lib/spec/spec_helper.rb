require_relative '../genData'

RSpec.configure do |config|
  config.color = true
  config.formatter = :documentation
end
