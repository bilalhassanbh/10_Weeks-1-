require 'capybara'

# register chrome driver with capybara

Capybara.register_driver :chrome do |app|
  Capybara::Selenium::Driver.new(app, :browser => :chrome)
end

# Create a new session
session = Capybara::Session.new(:chrome)

# Use the visit method to navigate to the page
session.visit('http://toolsqa.com/automation-practice-form/')

session.fill_in('firstname', with: 'test')
session.fill_in('lastname', with: 'test2')

# Radio buttons
session.choose('sex-0')
session.choose('exp-6')

# Date picker
session.fill_in('datepicker', with: '01/01/2019')

# Profession
session.check('profession-1')

# Automation tool
session.check('tool-2')

# Select Europe from continents
session.select('Europe', from: 'continents')

# Select WebElement commands from selenium commands
session.select('WebElement Commands', from: 'selenium_commands')

# click button
sessoin.click_button('submit')

sleep 3
