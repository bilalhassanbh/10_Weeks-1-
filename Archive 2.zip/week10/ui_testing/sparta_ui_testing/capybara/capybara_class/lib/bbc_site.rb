# SUPER class
require_relative 'pages/bbc_homepage'
require_relative 'pages/bbc_sign_in_page'
require_relative 'pages/bbc_register'

class BBCsite

  def bbc_homepage
    BBChomepage.new
  end

  def bbc_sign_in_page
    BBCSignInPage.new
  end

  def bbc_register
    BBCregister.new
  end

end
