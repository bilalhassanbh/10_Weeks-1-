require 'capybara/dsl'

class BBChomepage

  include Capybara::DSL

  #HOMEPAGE URL
  HOMEPAGE_URL = 'https://www.bbc.co.uk'
  SIGN_IN_LINK_ID = '#idcta-link'

  def visit_homepage
    visit(HOMEPAGE_URL)
  end

  def sign_in_link_id
    find(SIGN_IN_LINK_ID)
  end

  def click_sign_in_link
    find(SIGN_IN_LINK_ID).click
  end

end
