require 'capybara/dsl'

class BBCSignInPage

  USERNAME = 'user-identifier-input'
  PASSWORD = 'password-input'
  SUBMIT_BUTTON = 'submit-button'
  GENERAL_ERROR_MESSAGE = 'form-message-general'
  ERROR_MESSAGE_USERNAME = 'form-message-username'
  ERROR_MESSAGE_PASSWORD = 'form-message-password'

  include Capybara::DSL

  def fill_in_username un
    fill_in(USERNAME, with: un)
  end

  def fill_in_password pw
    fill_in(PASSWORD, with: pw)
  end

  def click_sign_in_button
    click_button(SUBMIT_BUTTON)
  end

  def incorrect_password_text
    "Sorry, we can’t find an account with that username. If you're over 13, try your email address instead or get help here."
  end

  def check_genral_error_message
    find_by_id(GENERAL_ERROR_MESSAGE).text
  end

  def check_error_message
    find_by_id(ERROR_MESSAGE_USERNAME).text
  end

  def check_passowrd_error_message
    find_by_id(ERROR_MESSAGE_PASSWORD).text
  end

  def check_username
    find_by_id(USERNAME).text
  end

  def check_password
    find_by_id(PASSWORD).text
  end

  def click_register_link
    click_link('Register now')
  end

end
