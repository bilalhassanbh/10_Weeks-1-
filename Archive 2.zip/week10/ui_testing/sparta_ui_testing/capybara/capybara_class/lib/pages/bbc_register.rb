require 'capybara/dsl'

class BBCregister

  include Capybara::DSL

  UNDER_13 = 'Under 13'
  PARENTS_EMAIL = 'email-input'
  SUBMIT_BUTTON = 'submit-button'
  ERROR_MESSAGE = 'form-message-email'

  def click_13
    click_link(UNDER_13)
  end

  def enter_parents_email pe
    fill_in(PARENTS_EMAIL, with: pe)
  end

  def click_send_email
    click_button(SUBMIT_BUTTON)
  end

  def error_message
    find_by_id(ERROR_MESSAGE).text
  end




end
