require 'spec_helper'

describe 'Incorrect user details produces valid error' do

  context 'it should respond with a correct error when incorrect deatils are input' do

    it 'should produce an error when inputting an incorrect password into an invalid account' do
      @bbc_site = BBCsite.new
      @bbc_site.bbc_homepage.visit_homepage
      @bbc_site.bbc_homepage.click_sign_in_link
      @bbc_site.bbc_sign_in_page.fill_in_username('TestUser1')
      @bbc_site.bbc_sign_in_page.fill_in_password('TestPassword1')
      @bbc_site.bbc_sign_in_page.click_sign_in_button
      expect(@bbc_site.bbc_sign_in_page.incorrect_password_text).to eq "Sorry, we can’t find an account with that username. If you're over 13, try your email address instead or get help here."
    end

  end

  context 'it should respond with the correct error when no detail are entered' do

      it 'should produce three errors when no username or password is entered' do
          @bbc_site = BBCsite.new
          @bbc_site.bbc_homepage.visit_homepage
          @bbc_site.bbc_homepage.click_sign_in_link
          @bbc_site.bbc_sign_in_page.click_sign_in_button
          #
          expect(@bbc_site.bbc_sign_in_page.check_genral_error_message).to eq 'Sorry, those details don\'t match. Check you\'ve typed them correctly.'
          expect(@bbc_site.bbc_sign_in_page.check_error_message).to eq 'Something\'s missing. Please check and try again.'
          expect(@bbc_site.bbc_sign_in_page.check_passowrd_error_message).to eq 'Something\'s missing. Please check and try again.'
          expect(@bbc_site.bbc_sign_in_page.check_username.empty?).to be true
          expect(@bbc_site.bbc_sign_in_page.check_password.empty?).to be true
      end
    end

    context 'it should respond with the correct errors when the password and username is too short' do

        it 'should produce two errors when the username and password are too short' do
            @bbc_site = BBCsite.new
            @bbc_site.bbc_homepage.visit_homepage
            @bbc_site.bbc_homepage.click_sign_in_link
            @bbc_site.bbc_sign_in_page.fill_in_username('d')
            @bbc_site.bbc_sign_in_page.fill_in_password('1')
            @bbc_site.bbc_sign_in_page.click_sign_in_button
            expect(@bbc_site.bbc_sign_in_page.check_error_message).to eq 'Sorry, that username\'s too short. It needs to be at least two characters.'
            expect(@bbc_site.bbc_sign_in_page.check_passowrd_error_message).to eq 'Sorry, that password is too short. It needs to be eight characters or more.'
            @bbc_site.bbc_sign_in_page.click_sign_in_button
            expect(@bbc_site.bbc_sign_in_page.check_genral_error_message).to eq 'Sorry, those details don\'t match. Check you\'ve typed them correctly.'
        end
    end

    context ' it should respond with the corrcet erros whena user tries to register when under 13 years old.' do

      it 'should produce an error message when the user tries to regsiter when under 13 and inputs incorrect details in the parents email.' do
        @bbc_site = BBCsite.new
        @bbc_site.bbc_homepage.visit_homepage
        @bbc_site.bbc_homepage.click_sign_in_link
        @bbc_site.bbc_sign_in_page.click_register_link
        @bbc_site.bbc_register.click_13
        @bbc_site.bbc_register.enter_parents_email('d')
        @bbc_site.bbc_register.click_send_email
        expect(@bbc_site.bbc_register.error_message).to eq 'Sorry, that doesn\'t look right. Please check it\'s a proper email.'



      end

    end

end
